package com.CostcutterStore.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage {
	
	@FindBy(xpath="//*[@id=\"findOptions\"]/div[1]/form/fieldset/button")
    public static WebElement findmystorebutton;
	
	@FindBy(xpath="//*[@id=\"findOptions\"]/div[2]/a")
	public static WebElement findbylocateme;
	
	@FindBy(name="searchLocation")
	public static WebElement storesearchlocationtextbox;
	
	//@FindBy(xpath="//*[@id=\"findOptions\"]/div[1]/form/fieldset/button")
    //public static WebElement findmystorebutton;
	
	
	
	
	public void searchByCity(String location) {
		storesearchlocationtextbox.sendKeys(location);
		findmystorebutton.click();
		
	}

    public void searchByCustomerLocation() {
    	
    	findbylocateme.click();
    }
	
}
