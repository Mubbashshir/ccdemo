package com.CostcutterStore.Pages;

import java.text.NumberFormat;
import java.util.List;
import java.util.logging.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import Utils.TestBase;
import org.openqa.selenium.support.ByIdOrName;
import org.openqa.selenium.By;


public class StoreFinderPage extends TestBase {

	private static final String Driver = null;
	
	@FindBy(xpath="//*[@id=\"totals\"]/div/h3")
	public static WebElement numberofstores;
	
	public  int getnumberofstorelocatorsvalidinputs(){
	String count=numberofstores.getText();
	String[] str1=count.split(" ");
	int num=Integer.parseInt(str1[0]);
    return(num);
   
    	}

	
		public  int getnumberofstorelocatorsinvalidinputs(){
		String count=numberofstores.getText();
		String[] str2=count.split(" ");
		int num1=Integer.parseInt(str2[0]);
	    return(num1);
		}
	
	
	public  int CCStorePage(){
	     
		//driver.get("https://www.costcutter.co.uk/");
		String url = driver.getCurrentUrl();
		System.out.println("The Results of current Url " +url);
		int num3;
		if(url.equals("https://www.costcutter.co.uk/location-finder/")) 
	      num3=1;
		else
	      num3=0;
		 return(num3);
		}
	
	
}






  // By storecount =By.id(results);
  //public static WebElement cowelement;
  //storecount.findElements(arg0);
    
   //List<WebElement> SC=driver.findElements(storecount);
   //*[@id="results"]/div[1]/div
   //*[@id="results"]/div[1]/div/div[1]
	 
	//if (num>=1) {
			//System.out.println("Number of Store found"+num);
		//Logger log= Logger.getLogger("devpinoyLogger");
		//log.info(num);
		//log.info("This info");
			
		//else
	//{
	//	System.out.println("Number of Store found"+num);
	//}
	
	
//}
