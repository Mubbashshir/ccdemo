package com.cc.storepageteststeps;
import java.awt.List;
import java.io.IOException;
import java.sql.Driver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import com.CostcutterStore.Pages.HomePage;
import com.CostcutterStore.Pages.StoreFinderPage;
import Utils.TestBase;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.DriverManagerType;
import io.github.bonigarcia.wdm.WebDriverManager;

public class StorepageTestSteps extends TestBase{
	int storenum;
	//Positive Scenarios City and Post code search
	HomePage homepage=null;
	StoreFinderPage storefinderpage=null;
	
	@Before
	public void setup() throws IOException {
	    initialize();
		log.debug("before");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
			
	}
	
	

	@Given("user is on CostCutter StorePage")
	public void user_is_on_CostCutter_StorePage() throws IOException {
		//initialize();
		driver.get(CONFIG.getProperty("testsiteName")); 
		log.debug("Given");
	
	}
	
	
	@When("valid city i.e. {string}  is entered in searchLocation text field")
	public void valid_city_i_e_is_entered_in_searchLocation_text_field_all_the_the_stores_in_York_should_be_displayed(String string) {
		
		 
		 homepage = PageFactory.initElements(driver, HomePage.class);
		 homepage.searchByCity(string);
		 log.debug("");
		 try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		 

		 @Then("the search is successful and total number to stores found in that city are displayed")
		 public void the_search_is_successful_and_total_number_to_stores_found_in_that_city_are_displayed() {
			 storefinderpage=PageFactory.initElements(driver, StoreFinderPage.class);
			 System.out.println("The total number of  valid Stores found in this city/town are " +storefinderpage.getnumberofstorelocatorsvalidinputs());
			 log.debug("The total number of  valid Stores found in this city/town are " + storefinderpage.getnumberofstorelocatorsvalidinputs());	 	
		 }
		 
		
		 

	

   @When("valid postcode i.e {string} is entered in searchLocation text field")
   public void valid_postcode_i_e_is_entered_in_searchLocation_text_field(String string) {
    // Write code here that turns the phrase above into concrete actions
	   homepage = PageFactory.initElements(driver, HomePage.class);
		 homepage.searchByCity(string);
		 try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }


   @Then("the search is successful and total number of stores found in that post code are displayed")
   public void the_search_is_successful_and_total_number_of_stores_found_in_that_post_code_are_displayed() {
       // Write code here that turns the phrase above into concrete actions
	   storefinderpage=PageFactory.initElements(driver, StoreFinderPage.class);
	   System.out.println("The total number of  valid Stores found in this post code are "+  storefinderpage.getnumberofstorelocatorsvalidinputs());
		 	
   }


  //Negative Scenarios for city and post code search. 
   
   @When("invalid city i.e. {string} is entered in searchLocation text field")
   public void invalid_city_i_e_is_entered_in_searchLocation_text_field(String string) {
       // Write code here that turns the phrase above into concrete actions
       
       homepage = PageFactory.initElements(driver, HomePage.class);
	   homepage.searchByCity(string);
	   try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   }

   @Then("the search is unsuccessful and zero stores\\/no stores are found for invalid city\\/town search")
   public void the_search_is_unsuccessful_and_zero_stores_no_stores_are_found_for_invalid_city_town_search() {
       // Write code here that turns the phrase above into concrete actions
       
       storefinderpage=PageFactory.initElements(driver, StoreFinderPage.class);
	   System.out.println("The total number of Stores found for invalid city/Town are"+  storefinderpage.getnumberofstorelocatorsinvalidinputs());
	    storenum=storefinderpage.getnumberofstorelocatorsinvalidinputs();
	    if (storenum > 1)
	    System.out.println("The Test Case has failed because the count of stores is expected to zero for invalid city or town");
	    storenum=0;
   }

   @When("invalid post code i.e. {string} is entered in searchLocation text field")
   public void invalid_post_code_i_e_is_entered_in_searchLocation_text_field(String string) {
       // Write code here that turns the phrase above into concrete actions
	   homepage = PageFactory.initElements(driver, HomePage.class);
	   homepage.searchByCity(string);
	   try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   }

   @Then("the search is unsuccessful and zero stores\\/no stores are found for invalid post code search")
   public void the_search_is_unsuccessful_and_zero_stores_no_stores_are_found_for_invalid_post_code_search() {
       // Write code here that turns the phrase above into concrete actions
	  storefinderpage=PageFactory.initElements(driver, StoreFinderPage.class);
	   System.out.println("The total number of  invalid Stores found for invalid city or postcode are "+ storefinderpage.getnumberofstorelocatorsinvalidinputs());
	     storenum=0;
	    storenum=storefinderpage.getnumberofstorelocatorsinvalidinputs();
	    if (storenum > 1)
	    System.out.println("The Test Case has failed because the count of stores is expected to zero for invalid city or town");
	    storenum=0;
   }
   
   
   
   @When("special charecters such as {string}\" are entered in searchLocation text field")
   public void special_charecters_such_as_are_entered_in_searchLocation_text_field(String string) {
       
	   homepage = PageFactory.initElements(driver, HomePage.class);
	   homepage.searchByCity(string);
	   try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	   
	   
   }

   @Then("the search button does not produce any results and use remains on store page")
   public void the_search_button_does_not_produce_any_results_and_use_remains_on_store_page() {
       // Write code here that turns the phrase above into concrete actions
       
	   storefinderpage=PageFactory.initElements(driver, StoreFinderPage.class);
	   int SR=storefinderpage.CCStorePage();
	   if(SR==1)
		   System.out.println("Test Passed-Results are not displayed for store search using special characters");
		   else
		   System.out.println("Test Failed- Results are displayed for store search using special charecters");
   }


   

@When("user clicks locate me button from either UK or Ireland")
public void user_clicks_locate_me_button_from_either_UK_or_Ireland() {
    // Write code here that turns the phrase above into concrete actions
	homepage = PageFactory.initElements(driver, HomePage.class);
	homepage.searchByCustomerLocation();
	 try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
}

@Then("list of all valid  CC stores should be displayed")
public void list_of_all_valid_CC_stores_should_be_displayed() {
    // Write code here that turns the phrase above into concrete actions
	 storefinderpage=PageFactory.initElements(driver, StoreFinderPage.class);
	 System.out.println("The total number of  valid Stores located by locate me button " +storefinderpage.getnumberofstorelocatorsvalidinputs());
		 	

    
}

	
@After
public void cleardown(){
    driver.quit();
	driver=null;
	
	
}



} 




	



