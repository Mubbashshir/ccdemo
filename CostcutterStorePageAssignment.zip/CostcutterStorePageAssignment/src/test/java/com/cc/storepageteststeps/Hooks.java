/*//package com.cc.storepageteststeps;

import java.io.IOException;

//import Utils.TestBase;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks extends TestBase {
	
	@Before
	public void setup() throws IOException {
		initialize();
	}
	
	
	@After
	public void cleardown(){

		driver.close();
		
	}

}
*/