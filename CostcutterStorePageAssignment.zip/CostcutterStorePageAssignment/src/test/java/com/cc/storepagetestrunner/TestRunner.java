/**
 * 
 */
package com.cc.storepagetestrunner;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

/**
 * @author User
 *
 */
@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\Users\\User\\git\\ccdemo\\CostcutterStorePageAssignment\\src\\test\\resources\\features",
                 glue = {"com.cc.storepageteststeps"},
plugin={ "json:target/cucumber.json",
"html:target/site/cucumber-pretty"})
public class TestRunner {
}


//C:\\Users\\User\\eclipse-workspace\\CostcutterStorePageAssignment\\src\\test\\resources\\features